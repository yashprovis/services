package com.socialproxy.proxyservice.exceptions;

public class FrpcClientException extends Exception {

    public FrpcClientException(String message) {
        super(message);
    }

}
