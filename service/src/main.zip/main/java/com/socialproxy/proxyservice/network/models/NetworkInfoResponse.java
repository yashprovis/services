package com.socialproxy.proxyservice.network.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NetworkInfoResponse {

    private String query;
    private String isp;
    private String org;
    private String as;
    private String country;
    private String regionName;
    private String city;

    public NetworkInfoResponse(
            @JsonProperty("query") String query,
            @JsonProperty("isp") String isp,
            @JsonProperty("org") String org,
            @JsonProperty("as") String as,
            @JsonProperty("country") String country,
            @JsonProperty("regionName") String regionName,
            @JsonProperty("city") String city) {
        this.query = query;
        this.isp = isp;
        this.org = org;
        this.as = as;
        this.country = country;
        this.regionName = regionName;
        this.city = city;
    }

    public String getQuery() {
        return query;
    }

    public String getIsp() {
        return isp;
    }

    public String getOrg() {
        return org;
    }

    public String getAs() {
        return as;
    }

    public String getCountry() {
        return country;
    }

    public String getRegionName() {
        return regionName;
    }

    public String getCity() {
        return city;
    }
}
