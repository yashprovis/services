package com.socialproxy.proxyservice.logging.log;

public abstract class Logger {

    public abstract void i(String tag, String msg);

    public abstract void d(String tag, String msg);

    public abstract void e(String tag, String msg);

}
