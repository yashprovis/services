package com.socialproxy.proxyservice.utils;


import com.socialproxy.proxyservice.models.frp.FrpServerCredentials;
import com.socialproxy.proxyservice.models.frp.FrpTunnelConfig;
import com.socialproxy.proxyservice.network.models.FrpServerCredentialsResponse;

import java.util.ArrayList;

public class Mapper {

    public FrpServerCredentials fromNetworkToFrpServerCredentials(
            FrpServerCredentialsResponse response) {
        return new FrpServerCredentials(
                response.getServerAddress(),
                response.getServerPort(),
                response.getToken());
    }

    public FrpTunnelConfig fromNetworkToFrpTunnelConfig(FrpServerCredentialsResponse response) {
        FrpTunnelConfig config = new FrpTunnelConfig(
                response.getExtras().get("local_port") != null ? Integer.parseInt(response.getExtras().get("local_port")) : 6000); //TODO: remove hardcoded port
//        config.setTunnelName(response.getName());
//        config.setGroup(response.getGroup());
//        config.setGroupKey(response.getGroupKey());
//        config.setHealthType(response.getHealthCheckType());
//        config.setHealthFailed(response.getHealthCheckMaxFailed());
//        config.setHealthInterval(response.getHealthCheckInterval());
//        config.setHealthTimeout(response.getHealthCheckTimeout());
//        config.setCustomDomain(response.getCustomDomain());
        config.setExtras(response.getExtras());
        return config;
    }

}
