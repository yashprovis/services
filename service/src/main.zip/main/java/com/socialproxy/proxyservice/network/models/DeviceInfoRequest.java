package com.socialproxy.proxyservice.network.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DeviceInfoRequest {

    public static final DeviceInfoRequest EMPTY = new DeviceInfoRequest();

    private String networkStatus;
    private String ip;
    private String isp;
    private String org;
    private String as;
    private String country;
    private String regionName;
    private String city;

    public DeviceInfoRequest(
            @JsonProperty("networkStatus") String networkStatus,
            @JsonProperty("ip") String ip,
            @JsonProperty("isp") String isp,
            @JsonProperty("org") String org,
            @JsonProperty("as") String as,
            @JsonProperty("country") String country,
            @JsonProperty("regionName") String regionName,
            @JsonProperty("city") String city) {
        this.networkStatus = networkStatus;
        this.ip = ip;
        this.isp = isp;
        this.org = org;
        this.as = as;
        this.country = country;
        this.regionName = regionName;
        this.city = city;
    }

    private DeviceInfoRequest() {
    }

    public String getNetworkStatus() {
        return networkStatus;
    }

    public String getIp() {
        return ip;
    }

    public String getIsp() {
        return isp;
    }

    public String getOrg() {
        return org;
    }

    public String getAs() {
        return as;
    }

    public String getCountry() {
        return country;
    }

    public String getRegionName() {
        return regionName;
    }

    public String getCity() {
        return city;
    }
}
