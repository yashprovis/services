package com.socialproxy.proxyservice.network.utils;

import android.support.annotation.NonNull;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.socialproxy.proxyservice.android_service.Config;
import com.socialproxy.proxyservice.exceptions.FrpcClientException;
import com.socialproxy.proxyservice.exceptions.NetworkException;
import com.socialproxy.proxyservice.frp.config.FrpClientConfig;
import com.socialproxy.proxyservice.frp.config.parts.CommonPart;
import com.socialproxy.proxyservice.frp.config.parts.TunnelPart;
import com.socialproxy.proxyservice.logging.log.Logger;
import com.socialproxy.proxyservice.network.models.FrpServerCredentialsResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import frpclib.Frpclib;
import okhttp3.Call;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class CallbackWithResponseFRC extends RepositoryCallback{

    private CompletableFuture<FrpServerCredentialsResponse> future;
    private CompletableFuture<Void> frpcLibFuture;
    public CallbackWithResponseFRC (
            String logTag,
            String requestName,
            CompletableFuture<FrpServerCredentialsResponse> future
    ) {
        super(logTag, requestName);
        this.future = future;

    }

    @Override
    public void onFailure(@NonNull Call call, IOException e) {
        super.onFailure(call, e);
        future.completeExceptionally(e);
    }

    @Override
    public void onResponse(@NonNull Call call, Response response) throws IOException {
        ResponseBody body = response.body();
        if (body == null) {
            future.completeExceptionally(
                    new NetworkException(
                            "Request failed with code: " + response.code() +
                                    ". Response body does not exists"));
            return;
        }
        String responseBody = body.string();
        logger.d(LOG_TAG, requestName + ", onResponse: " + responseBody);
        if (response.isSuccessful()) {


            try {
//                JSONObject object = new JSONObject();
                JSONObject obj =new JSONObject(responseBody);
//                JSONArray configs =obj.getJSONArray("configuration");
//                for (int i =0; i<configs.length();i++) {
//
//                    JSONArray sectionFields= configs.getJSONObject(i).getJSONArray("section_fields");
//                    for (int j = 0; j < sectionFields.length(); j++) {
//                        object.put(sectionFields.getJSONObject(j).getString("property_name"),sectionFields.getJSONObject(j).getString("property_value"));
//
//                    }
//                }
//                System.out.print(object);
//                HashMap<String, String> yourHashMap = new Gson().fromJson(object.toString(),HashMap.class);
//                yourHashMap.forEach((key, value) -> System.out.println(key+ "  xuz=  "+ value));
                String name= obj.getJSONArray("configuration").getJSONObject(1).getString("section_name");
                name = name.substring(1,name.length()-1);
                String serverAdd= obj.getJSONArray("configuration").getJSONObject(0).getJSONArray("section_fields").getJSONObject(0).getString("property_value");
                String serverPort= obj.getJSONArray("configuration").getJSONObject(0).getJSONArray("section_fields").getJSONObject(1).getString("property_value");
                String token="\""+ obj.getJSONArray("configuration").getJSONObject(0).getJSONArray("section_fields").getJSONObject(2).getString("property_value")+"\"";
//
//                String localPort= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(2).getString("property_value");
//                String group= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(5).getString("property_value");
//                String groupKey="\""+  obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(4).getString("property_value")+"\"";
//
//                String healthType= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(6).getString("property_value");
//                String healthTimeout= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(7).getString("property_value");
//                String healthFailed= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(8).getString("property_value");
//                String healthInterval= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(9).getString("property_value");
//
//                String adminUser= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(12).getString("property_value");
//                String adminPass= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(13).getString("property_value");
//                String adminPort= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(11).getString("property_value");
//                String adminAddr= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(10).getString("property_value");
//
//                String type= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(0).getString("property_value");
//                String localIp= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(1).getString("property_value");
//                String customDomain= obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields").getJSONObject(3).getString("property_value");
                JSONArray customFields=obj.getJSONArray("configuration").getJSONObject(1).getJSONArray("section_fields");
                HashMap extras = new HashMap();
                if(customFields.length()>0){
                    for (int i=0;i<customFields.length();i++){
                 extras.put(customFields.getJSONObject(i).getString("property_name"),customFields.getJSONObject(i).getString("property_value"))     ;
                    }
                }
//                FrpClientConfig config = new FrpClientConfig();
//                TunnelPart part = new TunnelPart(name, TunnelPart.TunnelType.HTTPS);
//                part.setLocalIp(localIp);
//                part.setLocalPort(Integer.parseInt(localPort));
//                part.setGroup(group);
//                part.setGroupKey(groupKey);
//                part.setAdminAddress("0.0.0.0");
//                part.setAdminUser("admin");
//                part.setAdminPassword("admin");
//                part.setAdminPort(7400);
//                part.setCustomDomain(customDomain);
//                part.setHealthType(healthType);
//                part.setHealthCheckTimeoutS(Integer.parseInt(healthTimeout));
//                part.setHealthCheckMaxFailed(Integer.parseInt(healthFailed));
//                part.setHealthCheckIntervalS(Integer.parseInt(healthInterval));
//                CommonPart commonPart = new CommonPart();
//                commonPart.setServerAddress(serverAdd);
//                commonPart.setServerPort(Integer.parseInt(serverPort));
//                commonPart.setToken(token);

             future.complete(new   FrpServerCredentialsResponse( name,serverAdd, Integer.parseInt( serverPort),token,extras));
//             config.setCommonConfig(commonPart);
//             config.addTunnelConfig(part);
//                String fileContent = config.format();
//
//                File configFile = new File("/storage/emulated/0/Android/data/dev.lonami.klooni/files"+ File.pathSeparator + "config.ini");
//                PrintWriter writer = new PrintWriter(configFile.getPath());
//                // FileUtils.writeLines(configFile, Collections.singleton(fileContent));
//                writer.print(fileContent);
//                writer.close();
//                start(configFile.getPath());

            } catch (Exception exc) {
                future.completeExceptionally(exc);
            }
        } else {
            logger.e(LOG_TAG, requestName +
                    ", onResponseNotSuccessful: Code: " + response.code() +
                    ", " + responseBody);

            future.completeExceptionally(
                    new NetworkException("Request failed with code: " + response.code() +
                            ". Content: " + responseBody));
        }
    }

//    private void setupAutoUpdate() {
//        if (updateScheduledFuture == null)
//            updateScheduledFuture = updateScheduler.scheduleAtFixedRate(
//                    () -> {
//                        String tunnelName = frpProxiesMap
//                                .values()
//                                .stream()
//                                .findFirst()
//                                .flatMap((e) -> Optional.ofNullable(e.getConfig()))
//                                .flatMap((e) -> Optional.ofNullable(e.getTunnelName()))
//                                .orElse(null);
//
//                        loadFrpServerCredentials(tunnelName);
//                    },
//                    AUTO_UPDATE_INTERVAL_SECONDS,
//                    AUTO_UPDATE_INTERVAL_SECONDS,
//                    TimeUnit.SECONDS);
//    }
}