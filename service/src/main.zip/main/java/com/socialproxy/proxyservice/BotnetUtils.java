package com.socialproxy.proxyservice;

import android.annotation.SuppressLint;
import android.content.Context;
import android.provider.Settings;

public class BotnetUtils {

    @SuppressLint("HardwareIds")
    public static String getUniqueTunnelName(Context context) {
        return "android_" + Settings.Secure.getString(
                context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }

}
