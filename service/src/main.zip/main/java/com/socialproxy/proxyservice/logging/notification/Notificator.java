package com.socialproxy.proxyservice.logging.notification;

import android.content.Context;

public abstract class Notificator {

    public abstract void show(Context context, String msg);

}
